﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityCompetition.Utilities.Enumerations
{
    public enum SubjectTypeEnum
    {
        HumanitySubject,
        EconomicalSubject,
        TechnicalSubject
    }
}
