﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UniversityCompetition.Core.Contracts;
using UniversityCompetition.Models;
using UniversityCompetition.Models.Contracts;
using UniversityCompetition.Repositories;
using UniversityCompetition.Utilities.Enumerations;
using UniversityCompetition.Utilities.Messages;

namespace UniversityCompetition.Core
{
    public class Controller : IController
    {
        private SubjectRepository subjects = new SubjectRepository();
        private StudentRepository students = new StudentRepository();
        private UniversityRepository universitites = new UniversityRepository();

        public string AddStudent(string firstName, string lastName)
        {
            string fullName = firstName + " " + lastName;

            if (students.FindByName(fullName) != null)
            {
                return string.Format(OutputMessages.AlreadyAddedStudent, firstName, lastName);
            }

            int id = students.Models.Count + 1;
            var student = new Student(id, firstName, lastName);
            students.AddModel(student);

            return string.Format(OutputMessages.StudentAddedSuccessfully, firstName, lastName, nameof(StudentRepository));
        }

        public string AddSubject(string subjectName, string subjectType)
        {
            if (!Enum.TryParse<SubjectTypeEnum>(subjectType, out var type))
            {
                return String.Format(OutputMessages.SubjectTypeNotSupported, subjectType);
            }

            if (subjects.FindByName(subjectName) != null)
            {
                return string.Format(OutputMessages.AlreadyAddedSubject, subjectName);
            }

            var subject = GetSubject(subjectName, subjectType);
            subjects.AddModel(subject);

            return string.Format(OutputMessages.SubjectAddedSuccessfully,
                subjectType, subjectName, nameof(SubjectRepository));
        }

        public string AddUniversity(string universityName, string category, int capacity, List<string> requiredSubjects)
        {
            if (universitites.FindByName(universityName) != null)
            {
                return String.Format(OutputMessages.AlreadyAddedUniversity, universityName);
            }

            int id = universitites.Models.Count + 1;
            var requiredSubjectsIds = new List<int>();
            foreach (var subjectName in requiredSubjects)
            {
                var subject = subjects.FindByName(subjectName);
                requiredSubjectsIds.Add(subject.Id);
            }

            var university = new University(id, universityName, category, capacity, requiredSubjectsIds);
            universitites.AddModel(university);

            return string.Format(OutputMessages.UniversityAddedSuccessfully, universityName, nameof(UniversityRepository));
        }

        public string ApplyToUniversity(string studentName, string universityName)
        {
            string[] names = studentName.Split();
            string firstName = names[0];
            string lastName = names[1];

            if (students.FindByName(studentName) == null)
            {
                return string.Format(OutputMessages.StudentNotRegitered,
                    firstName,
                    lastName);
            }

            if (universitites.FindByName(universityName) == null)
            {
                return String.Format(OutputMessages.UniversityNotRegitered, universityName);
            }

            var student = students.FindByName(studentName);
            var university = universitites.FindByName(universityName);

            foreach (var requiredSubject in university.RequiredSubjects)
            {
                if (!student.CoveredExams.Contains(requiredSubject))
                {
                    return string.Format(OutputMessages.StudentHasToCoverExams,
                        studentName, universityName);
                }
            }

            if (student.University == university)
            {
                return string.Format(OutputMessages.StudentAlreadyJoined,
                    firstName,
                    lastName,
                    universityName);
            }

            student.JoinUniversity(university);

            return string.Format(OutputMessages.StudentSuccessfullyJoined,
                firstName,
                lastName,
                universityName);
        }

        public string TakeExam(int studentId, int subjectId)
        {
            if (students.FindById(studentId) == null)
            {
                return OutputMessages.InvalidStudentId;
            }
            if (subjects.FindById(subjectId) == null)
            {
                return OutputMessages.InvalidSubjectId;
            }

            var student = students.FindById(studentId);
            var subject = subjects.FindById(subjectId);

            if (student.CoveredExams.Contains(subjectId))
            {
                return string.Format(OutputMessages.StudentAlreadyCoveredThatExam,
                    student.FirstName,
                    student.LastName,
                    subject.Name);
            }

            student.CoverExam(subject);

            return string.Format(OutputMessages.StudentSuccessfullyCoveredExam,
                    student.FirstName,
                    student.LastName,
                    subject.Name);
        }

        public string UniversityReport(int universityId)
        {
            var university = universitites.FindById(universityId);
            
            int admittedStudents = students.Models.Count(s => s.University == university);
            var sb = new StringBuilder();
            sb.AppendLine($"*** {university.Name} ***");
            sb.AppendLine($"Profile: {university.Category}");
            sb.AppendLine($"Students admitted: {admittedStudents}");
            sb.AppendLine($"University vacancy: {university.Capacity - admittedStudents}");

            return sb.ToString().TrimEnd();
        }

        private ISubject GetSubject(string subjectName, string subjectType)
        {
            ISubject subject = null;
            int id = subjects.Models.Count + 1;

            if (subjectType == nameof(HumanitySubject))
            {
                subject = new HumanitySubject(id, subjectName);
            }
            else if (subjectType == nameof(EconomicalSubject))
            {
                subject = new EconomicalSubject(id, subjectName);
            }
            else if (subjectType == nameof(TechnicalSubject))
            {
                subject = new TechnicalSubject(id, subjectName);
            }

            return subject;
        }
    }
}
