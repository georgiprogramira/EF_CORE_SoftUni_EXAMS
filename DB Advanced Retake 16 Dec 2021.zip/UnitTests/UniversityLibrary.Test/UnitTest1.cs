namespace UniversityLibrary.Test
{
    using NUnit.Framework;
    using System.Text;

    [TestFixture]
    public class Tests
    {
        private UniversityLibrary library;

        [SetUp]
        public void SetUp()
        {
            library = new UniversityLibrary();
        }

        [TearDown]
        public void TearDown()
        {
            library = null;
        }

        [Test]
        public void TestConstructor()
        {
            Assert.That(library.Catalogue.Count, Is.EqualTo(0));
        }

        [Test]
        public void TestAddingTextBookCatalogueCount()
        {
            int expectedCountBeforeAddingBook = 0;
            int actualCountBeforeAddingBook = library.Catalogue.Count;

            var textBook = new TextBook("Crime and Punishment", "Dostoevski", "Novel");
            library.AddTextBookToLibrary(textBook);

            int expectedCountAfterAddingBook = 1;
            int actualCountAfterAddingBook = library.Catalogue.Count;

            Assert.AreEqual(expectedCountBeforeAddingBook, actualCountBeforeAddingBook);
            Assert.AreEqual(expectedCountAfterAddingBook, actualCountAfterAddingBook);
        }

        [Test]
        public void TestAddingTextBookParams()
        {
            var textBook = new TextBook("Crime and Punishment", "Dostoevski", "Novel");

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Book: {textBook.Title} - {library.Catalogue.Count + 1}");
            sb.AppendLine($"Category: {textBook.Category}");
            sb.AppendLine($"Author: {textBook.Author}");

            string result = library.AddTextBookToLibrary(textBook);
            string expectedResult = sb.ToString().TrimEnd();

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void TestLoaningBook()
        {
            var textBook1 = new TextBook("Crime and Punishment", "Dostoevski", "Novel");

            library.AddTextBookToLibrary(textBook1);
            string result = library.LoanTextBook(1, "Georgi");
            string expectedResult = $"Crime and Punishment loaned to Georgi.";

            Assert.AreEqual(expectedResult, result);
            Assert.That(textBook1.Holder, Is.EqualTo("Georgi"));
        }

        [Test]
        public void TestLoaningNotReturnedBook()
        {
            var textBook1 = new TextBook("It", "King", "Novel");
            library.AddTextBookToLibrary(textBook1);

            library.LoanTextBook(1, "Georgi");
            string result = library.LoanTextBook(1, "Georgi");
            string expectedResult = $"Georgi still hasn't returned It!";

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void TestReturningTextBook()
        {
            var textBook1 = new TextBook("It", "King", "Novel");
            library.AddTextBookToLibrary(textBook1);
            library.LoanTextBook(1, "Georgi");

            string result = library.ReturnTextBook(1);
            string expectedResult = $"It is returned to the library.";

            Assert.AreEqual(expectedResult, result);
            Assert.That(textBook1.Holder, Is.EqualTo(string.Empty));
        }
    }
}